package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Random;

public class EasyPanel extends JPanel implements ActionListener {


    private JButton jButton = new JButton("Press here to go to lvl 2");
    static int SCREEN_WIDTH = 800;
    protected int SCREEN_HEIGHT = 600;
    int UNIT_SIZE = 40;
    int GAME_UNITS = (SCREEN_WIDTH * SCREEN_HEIGHT) / UNIT_SIZE;
    int DELAY;
    int[] x = new int[GAME_UNITS];
    int[] y = new int[GAME_UNITS];
    int bodyParts = 1; //initial body parts
    int applesEaten = 0;
    int appleX;
    int appleY;//position of apple
    int cutX;
    int cutY;
    int bigAppleX;
    int bigAppleY;
    char direction = 'R'; //snake begin going to right
    boolean running = false; //snake no run in the beginning
    Timer timer;
    Random random;

    ImageIcon imageIcon = new ImageIcon("img.png");


    //constructor
    public EasyPanel() {
        this.DELAY = 65;
        random = new Random();
        this.setPreferredSize(new Dimension(SCREEN_WIDTH, SCREEN_HEIGHT));
        //Dimension is a class itself that have Dimension 2D child class, so it's a parent class
        this.setBackground(Color.black);
        this.setFocusable(true);//if this is false you can't control the snake
        //This method is extended to JPanel from JComponents, it's true in default,
        //It's like when you have some text fields and the user enter from one of them
        //so you must have focus on the text field that the user input in
        //so in this case you need focusable to be true not false.
        this.addKeyListener(new MyKeyAdapter());
        //Take an object from MyKeyAdapter down below that extennded from keyAdapter java class
        //and make the object parameter to addKeyLister panel sub method.
        startGame();
    }

    public void startGame() {
        newApple();
//        if (applesEaten % 5 == 0 && applesEaten > 1) {
            newBigApple();
//        }
        newCut();
        running = true; // game begin
        timer = new Timer(DELAY, this);
        timer.start();

    }

    public void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);
        draw(graphics);
    }

    public void draw(Graphics graphics) {
        if (running) {
            if (applesEaten >= 20) {
                graphics.setColor(Color.CYAN);
                graphics.setFont(new Font("Ink Free", Font.BOLD, 75));
                FontMetrics fontMetrics = getFontMetrics(graphics.getFont());
                graphics.drawString("You Pass lvl 1", (SCREEN_WIDTH - fontMetrics.stringWidth("You Pass lvl 1")) / 2, SCREEN_HEIGHT / 2);
            }
            //this to make it like matrix to make easier to see the components
            for (int i = 1; i < SCREEN_HEIGHT / UNIT_SIZE; i++) {
                // 600 / 25(each cell has 25) = 24 so we have 24 cells , so we have 23 lines
                graphics.drawLine(0, i * UNIT_SIZE, SCREEN_WIDTH, i * UNIT_SIZE);
                //drawLine(x1,y1 -> starting cordinates  x2,y2 ending cordinates)
            }
            for (int i = 1; i < SCREEN_WIDTH / UNIT_SIZE; i++) {

                graphics.drawLine(i * UNIT_SIZE, 0, i * UNIT_SIZE, SCREEN_HEIGHT);
            }
            //With these two loops i make grids fits for any shape (Width and height)

            //now we draw the apple

            graphics.setColor(Color.red);
            graphics.fillOval(appleX, appleY, UNIT_SIZE, UNIT_SIZE);//This is how large the apple is
//            graphics.drawImage(imageIcon.getImage(),appleX,appleY,null);

            //now we draw the cut

            graphics.setColor(Color.CYAN);
            graphics.fillOval(cutX, cutY, UNIT_SIZE, UNIT_SIZE);

            //Now we draw the big apple
            if (applesEaten % 5 == 0 && applesEaten > 1) {
                graphics.setColor(Color.MAGENTA);
                graphics.fillOval(bigAppleX, bigAppleY, UNIT_SIZE, UNIT_SIZE);
            }


            //now we draw the snake

            int randomColor1 = random.nextInt(255);
            int randomColor2 = random.nextInt(255);
            int randomColor3 = random.nextInt(255);

            for (int i = 0; i < bodyParts; i++) {
                if (i == 0) {
//                    graphics.setColor(Color.GREEN);
//                    graphics.setColor(new Color(random.nextInt(255), random.nextInt(255), random.nextInt(255)));
                    graphics.setColor(new Color(randomColor1, randomColor2, randomColor3));
                    //For making multiple color (Random)
                    graphics.fillRect(x[i], y[i], UNIT_SIZE, UNIT_SIZE);
                } else {
//                    graphics.setColor(new Color(45, 180, 0));
//                    graphics.setColor(new Color(random.nextInt(255), random.nextInt(255), random.nextInt(255)));
                    graphics.setColor(new Color(randomColor1, randomColor2, randomColor3));
                    graphics.fillRect(x[i], y[i], UNIT_SIZE, UNIT_SIZE);
                }
            }
            graphics.setColor(Color.red);
            graphics.setFont(new Font("Ink Free", Font.BOLD, 40));
            FontMetrics fontMetrics = getFontMetrics(graphics.getFont());
            graphics.drawString("Score: " + applesEaten, (SCREEN_WIDTH - fontMetrics.stringWidth("Score: " + applesEaten)) / 2, graphics.getFont().getSize());
        } else {
            gameOver(graphics);
        }
    }

    public void move() {
        for (int i = bodyParts; i > 0; i--) {
            x[i] = x[i - 1];
            y[i] = y[i - 1];
            //suppose we have 6 bodyParts...so we have 7 indexes
            //index 5 to 6, 4 to 5, 3 to 4 , 2 to 3, 1 to 2, 0 to 1
            //so all the bodyParts will go forward one index
        }
        switch (direction) {
            case 'U':
                y[0] = y[0] - UNIT_SIZE;
                break;
            case 'D':
                y[0] = y[0] + UNIT_SIZE;
                break;
            case 'L':
                x[0] = x[0] - UNIT_SIZE;
                break;
            case 'R':
                x[0] = x[0] + UNIT_SIZE;
                break;
        }
    }

    public void newApple() {
        appleX = random.nextInt(SCREEN_WIDTH / UNIT_SIZE) * UNIT_SIZE;
        //ranodm between 1 and 24 couse we have 24 cells
        //and then multiply by 25 so give the x position for the apple
        //the same thing with y position
        appleY = random.nextInt(SCREEN_HEIGHT / UNIT_SIZE) * UNIT_SIZE;
    }

    public void checkApple() {
        if ((x[0] == appleX) && (y[0] == appleY)) {
            bodyParts++;
            applesEaten++;
            newApple();//to generate a new apple

        }
    }

    public void newCut() {
        cutX = random.nextInt(SCREEN_WIDTH / UNIT_SIZE) * UNIT_SIZE;
        cutY = random.nextInt(SCREEN_HEIGHT / UNIT_SIZE) * UNIT_SIZE;
    }

    public void checkCut() {
        if ((x[0] == cutX) && (y[0] == cutY)) {
            bodyParts--;
            applesEaten++;
            newCut();
        }
    }

    public void newBigApple() {
        bigAppleX = random.nextInt(SCREEN_WIDTH / UNIT_SIZE) * UNIT_SIZE;
        bigAppleY = random.nextInt(SCREEN_HEIGHT / UNIT_SIZE) * UNIT_SIZE;
    }

    public void checkBigApple() {
        if ((x[0] == bigAppleX) && (y[0] == bigAppleY)) {
            applesEaten += 2;
            if (applesEaten % 5 == 0 && applesEaten > 1) {
                newBigApple();
            }
        }
    }


    public void checkCollisions() { //collisions == بەریەککەوتن
        //check if head collides with body
        for (int i = bodyParts; i > 0; i--) {
            if ((x[0] == x[i]) && (y[0] == y[i])) {
                running = false;
                break;
            }
        }
        //check if head touches left border
        if ((x[0] < 0)) {
            running = false;
        }
        //check if head touches right border
        if ((x[0] > SCREEN_WIDTH)) {
            running = false;
        }
        //check if head touches top border
        if (y[0] < 0) {
            running = false;
        }
        //check if head touches bottom border
        if (y[0] > SCREEN_HEIGHT) {
            running = false;
        }
        if (!running) {
            timer.stop();
        }

    }

    public void gameOver(Graphics g) {
        //Score
        g.setColor(Color.red);
        g.setFont(new Font("Ink Free", Font.BOLD, 40));
        FontMetrics fontMetrics1 = getFontMetrics(g.getFont());
        g.drawString("Score: " + applesEaten, (SCREEN_WIDTH - fontMetrics1.stringWidth("Score: " + applesEaten)) / 2, g.getFont().getSize());
        //Game Over text
        g.setColor(Color.red);
        g.setFont(new Font("Ink Free", Font.BOLD, 75));
        FontMetrics fontMetrics = getFontMetrics(g.getFont());
        g.drawString("Game Over", (SCREEN_WIDTH - fontMetrics.stringWidth("Game Over")) / 2, SCREEN_HEIGHT / 2);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // we call move method here

        if (applesEaten >= 20) {
            timer.stop();
            jButton.setBounds(200, 400, 400, 100);
            jButton.setVisible(true);
            jButton.setEnabled(true);
            jButton.setHorizontalTextPosition(JButton.CENTER);
            jButton.setVerticalTextPosition(JButton.CENTER);
            jButton.setFont(new Font("Roboto Mono", Font.BOLD, 30));
            jButton.addActionListener(this);
            this.add(jButton);
            if (e.getSource() == jButton) {
                new Lvl2AndNFrame();
            }
        }
        if (running) {
            move();
            checkApple();
            checkCut();
            checkCollisions();
            checkBigApple();
        }
        repaint();
    }

    public class MyKeyAdapter extends KeyAdapter {
        @Override
        public void keyPressed(KeyEvent e) {
            switch (e.getKeyCode()) {
                case KeyEvent.VK_LEFT:
                    if (direction != 'R') {
                        direction = 'L';
                    }
                    break;
                case KeyEvent.VK_RIGHT:
                    if (direction != 'L') {
                        direction = 'R';
                    }
                    break;
                case KeyEvent.VK_UP:
                    if (direction != 'D') {
                        direction = 'U';
                    }
                    break;
                case KeyEvent.VK_DOWN:
                    if (direction != 'U') {
                        direction = 'D';
                    }
                    break;
            }
        }
    }
}
