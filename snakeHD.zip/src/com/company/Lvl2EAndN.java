package com.company;

import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.IOException;

public class Lvl2EAndN extends EasyPanel {


    private JButton jButton = new JButton("Press here to go to lvl 3");
    int bombX;
    int bombY;

    Lvl2EAndN(){
        super();
        this.setBackground(Color.white);
    }

    @Override
    public void startGame() {
        this.DELAY = 35;
        super.startGame();
        newBomb();
    }


    @Override
    public void draw(Graphics graphics) {
        for (int i = 1; i < SCREEN_WIDTH / UNIT_SIZE; i++) {
            if (i * UNIT_SIZE == 200 || i * UNIT_SIZE == 600) {
                graphics.drawLine(i * UNIT_SIZE, 0, i * UNIT_SIZE, SCREEN_HEIGHT - 200);
            }
        }

        if (running) {
            if (applesEaten >= 50) {
                graphics.setColor(Color.CYAN);
                graphics.setFont(new Font("Ink Free", Font.BOLD, 75));
                FontMetrics fontMetrics = getFontMetrics(graphics.getFont());
                graphics.drawString("You Pass lvl 2", (SCREEN_WIDTH - fontMetrics.stringWidth("You Pass lvl 2")) / 2, SCREEN_HEIGHT / 2);
            }
            graphics.setColor(new Color(24, 10, 10));
            graphics.fillOval(bombX, bombY, UNIT_SIZE, UNIT_SIZE);
            //now we draw the apple

            graphics.setColor(Color.red);
            graphics.fillOval(appleX, appleY, UNIT_SIZE, UNIT_SIZE);//This is how large the apple is

            //now we draw the cut

            graphics.setColor(Color.CYAN);
            graphics.fillOval(cutX, cutY, UNIT_SIZE, UNIT_SIZE);

            //Now we draw the big apple
            if (applesEaten % 5 == 0 && applesEaten > 1) {
                graphics.setColor(Color.MAGENTA);
                graphics.fillOval(bigAppleX, bigAppleY, UNIT_SIZE, UNIT_SIZE);
            }


            //now we draw the snake

            int randomColor1 = random.nextInt(255);
            int randomColor2 = random.nextInt(255);
            int randomColor3 = random.nextInt(255);

            for (int i = 0; i < bodyParts; i++) {
                if (i == 0) {
//                    graphics.setColor(Color.GREEN);
//                    graphics.setColor(new Color(random.nextInt(255), random.nextInt(255), random.nextInt(255)));
                    graphics.setColor(new Color(randomColor1, randomColor2, randomColor3));
                    //For making multiple color (Random)
                    graphics.fillRect(x[i], y[i], UNIT_SIZE, UNIT_SIZE);
                } else {
//                    graphics.setColor(new Color(45, 180, 0));
//                    graphics.setColor(new Color(random.nextInt(255), random.nextInt(255), random.nextInt(255)));
                    graphics.setColor(new Color(randomColor1, randomColor2, randomColor3));
                    graphics.fillRect(x[i], y[i], UNIT_SIZE, UNIT_SIZE);
                }
            }
            graphics.setColor(Color.red);
            graphics.setFont(new Font("Ink Free", Font.BOLD, 40));
            FontMetrics fontMetrics = getFontMetrics(graphics.getFont());
            graphics.drawString("Score: " + applesEaten, (SCREEN_WIDTH - fontMetrics.stringWidth("Score: " + applesEaten)) / 2, graphics.getFont().getSize());
        } else {
            gameOver(graphics);
        }
    }


    public void newBomb() {
        bombX = random.nextInt(SCREEN_WIDTH / UNIT_SIZE) * UNIT_SIZE;
        bombY = random.nextInt(SCREEN_HEIGHT / UNIT_SIZE) * UNIT_SIZE;
    }

    public void checkBomb() {
        if (x[0] == bombX && y[0] == bombY) {
            running = false;
        }
    }

    @Override
    public void checkCollisions() {
//        for (int i = 1, s = 200, y1 = 25; i < SCREEN_WIDTH / UNIT_SIZE; i++, s += 800, y1 += 25) {
//            if (x[0] == s && y[0] == y1) {
//                running = false;
//            }
//        }
        super.checkCollisions();
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        // we call move method here

        if (applesEaten >= 50) {
            timer.stop();
            jButton.setBounds(200, 400, 400, 100);
            jButton.setVisible(true);
            jButton.setEnabled(true);
            jButton.setHorizontalTextPosition(JButton.CENTER);
            jButton.setVerticalTextPosition(JButton.CENTER);
            jButton.setFont(new Font("Roboto Mono", Font.BOLD, 30));
            jButton.addActionListener(this);
            this.add(jButton);
            if (e.getSource() == jButton) {
                new HardFrame();
            }
        }
        if (running) {
            move();
            checkApple();
            checkCut();
            checkBomb();
            checkCollisions();
            checkBigApple();
        }
        repaint();
    }
}
