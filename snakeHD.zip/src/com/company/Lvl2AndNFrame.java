package com.company;

import javax.swing.*;


public class Lvl2AndNFrame extends JFrame {
    ImageIcon imageIcon = new ImageIcon("snake.png");
    Lvl2AndNFrame(){
        this.add(new Lvl2EAndN());
        this.setTitle("Snake -> Easy||Normal Mode -> lvl 2");
        this.setIconImage(imageIcon.getImage());
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.pack();
        this.setVisible(true);
        this.setLocationRelativeTo(null);
    }
}
