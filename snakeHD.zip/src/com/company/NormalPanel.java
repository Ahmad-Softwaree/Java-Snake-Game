package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class NormalPanel extends EasyPanel {

    private JButton jButton = new JButton("Press here to go to lvl 2");

    public NormalPanel() {
        this.direction = 'D';
        this.setBackground(Color.DARK_GRAY);
    }


    @Override
    public void startGame() {
        this.DELAY = 50;
        super.startGame();

    }

    @Override
    public void draw(Graphics graphics) {
        if (running) {
            if (applesEaten >= 40) {
                graphics.setColor(Color.CYAN);
                graphics.setFont(new Font("Ink Free", Font.BOLD, 75));
                FontMetrics fontMetrics = getFontMetrics(graphics.getFont());
                graphics.drawString("You Pass Lvl 1", (SCREEN_WIDTH - fontMetrics.stringWidth("You Pass Lvl 1")) / 2, SCREEN_HEIGHT / 2);
            }

            //now we draw the apple

            graphics.setColor(Color.red);
            graphics.fillOval(appleX, appleY, UNIT_SIZE, UNIT_SIZE);//This is how large the apple is

            //now we draw the cut

            graphics.setColor(Color.CYAN);
            graphics.fillOval(cutX, cutY, UNIT_SIZE, UNIT_SIZE);

            //Now we draw the big apple
            if (applesEaten % 5 == 0 && applesEaten > 1) {
                graphics.setColor(Color.MAGENTA);
                graphics.fillOval(bigAppleX, bigAppleY, UNIT_SIZE, UNIT_SIZE);
            }


            //now we draw the snake

            int randomColor1 = random.nextInt(255);
            int randomColor2 = random.nextInt(255);
            int randomColor3 = random.nextInt(255);

            for (int i = 0; i < bodyParts; i++) {
                if (i == 0) {
//                    graphics.setColor(Color.GREEN);
//                    graphics.setColor(new Color(random.nextInt(255), random.nextInt(255), random.nextInt(255)));
                    graphics.setColor(new Color(randomColor1, randomColor2, randomColor3));
                    //For making multiple color (Random)
                    graphics.fillRect(x[i], y[i], UNIT_SIZE, UNIT_SIZE);
                } else {
//                    graphics.setColor(new Color(45, 180, 0));
//                    graphics.setColor(new Color(random.nextInt(255), random.nextInt(255), random.nextInt(255)));
                    graphics.setColor(new Color(randomColor1, randomColor2, randomColor3));
                    graphics.fillRect(x[i], y[i], UNIT_SIZE, UNIT_SIZE);
                }
            }
            graphics.setColor(Color.red);
            graphics.setFont(new Font("Ink Free", Font.BOLD, 40));
            FontMetrics fontMetrics = getFontMetrics(graphics.getFont());
            graphics.drawString("Score: " + applesEaten, (SCREEN_WIDTH - fontMetrics.stringWidth("Score: " + applesEaten)) / 2, graphics.getFont().getSize());
        } else {
            gameOver(graphics);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (applesEaten >= 40) {
            timer.stop();
            jButton.setBounds(200, 400, 400, 100);
            jButton.setVisible(true);
            jButton.setEnabled(true);
            jButton.setHorizontalTextPosition(JButton.CENTER);
            jButton.setVerticalTextPosition(JButton.CENTER);
            jButton.setFont(new Font("Roboto Mono", Font.BOLD, 30));
            jButton.addActionListener(this);
            this.add(jButton);
            if (e.getSource() == jButton) {
                new Lvl2AndNFrame();
            }
        }
        if (running) {
            move();
            checkApple();
            checkCut();
            checkCollisions();
            checkBigApple();
        }
        repaint();

    }
}
