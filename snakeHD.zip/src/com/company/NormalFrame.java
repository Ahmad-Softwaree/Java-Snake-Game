package com.company;

import javax.swing.*;

public class NormalFrame extends JFrame {
    ImageIcon imageIcon = new ImageIcon("snake.png");
    public NormalFrame() {
        this.add(new NormalPanel());
        this.setTitle("Snake -> Normal Mode -> lvl 1");
        this.setIconImage(imageIcon.getImage());
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.pack();
        this.setVisible(true);
        this.setLocationRelativeTo(null);
    }
}
