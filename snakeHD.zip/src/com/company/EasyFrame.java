package com.company;

import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.*;
import java.io.IOException;

public class EasyFrame extends JFrame {


    ImageIcon imageIcon = new ImageIcon("snake.png");

    //constructor
    public EasyFrame() {
        this.add(new EasyPanel());
        this.setTitle("Snake -> Easy Mode -> lvl 1");
        this.setIconImage(imageIcon.getImage());
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.pack(); //this will fit all the components within the frame
        //pack method extended to JFrame class from Window class
        this.setVisible(true);
        //This too from window parent class
        this.setLocationRelativeTo(null);//this will make appear in the middle of the screen
    }
}
