package com.company;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class StartupFrame extends JFrame implements ActionListener {
    JButton[] jButtons;
    JLabel[] jlabel;
    String[] lables = {"Snake Game", "Developer: Ahmad Software"};
    ImageIcon imageIcon1 = new ImageIcon("snake.png");
    private int labelWidth = 800;
    private int buttonWidth = 150;

    StartupFrame() {
        jlabel = new JLabel[2];
        for (int i = 0, y = 0, b = 50, x_cordinate = 150; i < jlabel.length; i++, y += 430, b -= 25, x_cordinate -= 25) {
            jlabel[i] = new JLabel(lables[i]);
            jlabel[i].setHorizontalTextPosition(JLabel.CENTER);
            jlabel[i].setVerticalTextPosition(JLabel.CENTER);
            jlabel[i].setBounds(x_cordinate, y, 400, 200);
            jlabel[i].setFont(new Font("Fido", Font.BOLD, b));
            jlabel[i].setForeground(new Color(0, 0, 0));
            this.add(jlabel[i]);
        }
        ImageIcon imageIcon = new ImageIcon("snake.jpg");
        JLabel jLabel = new JLabel(imageIcon);
        jLabel.setSize(labelWidth, 800);
        jLabel.setIcon(imageIcon);
        this.setIconImage(imageIcon1.getImage());
        this.setTitle("Snake Game");
        this.add(jLabel);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
        this.setResizable(false);
        this.pack();
        this.setLayout(null);
        jButtons = new JButton[3];
        String[] chose = {"Easy", "Normal", "Hard", "Insane"};
        for (int i = 0, y = 150; i < jButtons.length; i++, y += 120) {
            jButtons[i] = new JButton(chose[i]);
            jButtons[i].setFocusable(false);
            jButtons[i].setHorizontalTextPosition(JButton.CENTER);
            jButtons[i].setVerticalTextPosition(JButton.CENTER);
            jButtons[i].setVisible(true);
            jButtons[i].setForeground(new Color(0, 0, 0)); // set text color
            jButtons[i].setBackground(new Color(190, 221, 215));
            jButtons[i].setEnabled(true);
            jButtons[i].setBounds((labelWidth-buttonWidth)/3, y, buttonWidth, 100);
            jButtons[i].setBorder(BorderFactory.createEmptyBorder());
            jButtons[i].setFont(new Font("Roboto Mono", Font.BOLD, 30));
            jButtons[i].addActionListener(this);
            jLabel.add(jButtons[i]);
        }


    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == jButtons[0]) {
                new EasyFrame();
        }
        if (e.getSource() == jButtons[1]) {
            new NormalFrame();
        }
        if (e.getSource() == jButtons[2]) {
            new HardFrame();
        }
//        if (e.getSource() == jButtons[3]) {
//                InsaneFrame insaneFrame = new InsaneFrame();
//        }


    }
}
