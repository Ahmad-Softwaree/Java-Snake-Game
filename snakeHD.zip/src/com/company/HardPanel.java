package com.company;

import javax.sound.sampled.UnsupportedAudioFileException;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.IOException;

public class HardPanel extends EasyPanel {

    private int bombX;
    private int bombY;

    public HardPanel() {
    }

    @Override
    public void startGame() {
        this.DELAY = 25;
        super.startGame();
        newBomb();
    }

    public void newBomb() {
        bombX = random.nextInt(SCREEN_WIDTH / UNIT_SIZE) * UNIT_SIZE;
        bombY = random.nextInt(SCREEN_HEIGHT / UNIT_SIZE) * UNIT_SIZE;
    }

    public void checkBomb() {
        if ((x[0] == bombX) && (y[0] == bombY)) {
            bodyParts -= 3;
            applesEaten -= 3;
            newBomb();//to generate a new apple
        }
    }

    @Override
    public void draw(Graphics graphics) {
        if (running) {
            if (applesEaten >= 60) {
                graphics.setColor(Color.CYAN);
                graphics.setFont(new Font("Ink Free", Font.BOLD, 75));
                FontMetrics fontMetrics = getFontMetrics(graphics.getFont());
                graphics.drawString("You Pass lvl 3", (SCREEN_WIDTH - fontMetrics.stringWidth("You Pass lvl 3")) / 2, SCREEN_HEIGHT / 2);
            }
            //this to make it like matrix to make easier to see the components
            for (int i = 0; i < SCREEN_HEIGHT / UNIT_SIZE; i++) {
                // 600 / 25(each cell has 25) = 24 so we have 24 cells , so we have 23 lines
                graphics.drawLine(0, i * UNIT_SIZE, SCREEN_WIDTH, i * UNIT_SIZE);
                //drawLine(x1,y1 -> starting cordinates  x2,y2 ending cordinates)
            }
            for (int i = 0; i < SCREEN_WIDTH / UNIT_SIZE; i++) {

                graphics.drawLine(i * UNIT_SIZE, 0, i * UNIT_SIZE, SCREEN_HEIGHT);
            }
            //With these two loops i make grids fits for any shape (Width and height)

            //now we draw the apple

            graphics.setColor(Color.red);
            graphics.fillOval(appleX, appleY, UNIT_SIZE, UNIT_SIZE);//This is how large the apple is

            //now we draw the cut

            graphics.setColor(Color.CYAN);
            graphics.fillOval(cutX, cutY, UNIT_SIZE, UNIT_SIZE);

            graphics.setColor(Color.white);
            graphics.fillOval(bombX, bombY, UNIT_SIZE, UNIT_SIZE);
            //Now we draw the big apple
            if (applesEaten % 5 == 0 && applesEaten > 1) {
                graphics.setColor(Color.MAGENTA);
                graphics.fillOval(bigAppleX, bigAppleY, UNIT_SIZE, UNIT_SIZE);
            }


            //now we draw the snake

            int randomColor1 = random.nextInt(255);
            int randomColor2 = random.nextInt(255);
            int randomColor3 = random.nextInt(255);

            for (int i = 0; i < bodyParts; i++) {
                if (i == 0) {
//                    graphics.setColor(Color.GREEN);
//                    graphics.setColor(new Color(random.nextInt(255), random.nextInt(255), random.nextInt(255)));
                    graphics.setColor(new Color(randomColor1, randomColor2, randomColor3));
                    //For making multiple color (Random)
                    graphics.fillRect(x[i], y[i], UNIT_SIZE, UNIT_SIZE);
                } else {
//                    graphics.setColor(new Color(45, 180, 0));
//                    graphics.setColor(new Color(random.nextInt(255), random.nextInt(255), random.nextInt(255)));
                    graphics.setColor(new Color(randomColor1, randomColor2, randomColor3));
                    graphics.fillRect(x[i], y[i], UNIT_SIZE, UNIT_SIZE);
                }
            }
            graphics.setColor(Color.red);
            graphics.setFont(new Font("Ink Free", Font.BOLD, 40));
            FontMetrics fontMetrics = getFontMetrics(graphics.getFont());
            graphics.drawString("Score: " + applesEaten, (SCREEN_WIDTH - fontMetrics.stringWidth("Score: " + applesEaten)) / 2, graphics.getFont().getSize());
        } else {
            gameOver(graphics);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        this.setBackground(new Color(random.nextInt(255), random.nextInt(255), random.nextInt(255)));
        if (applesEaten >= 60) {
            timer.stop();
        }
        if (running) {
            move();
            checkApple();
            checkCut();
            checkCollisions();
            checkBigApple();
            checkBomb();
        }
        repaint();
    }


}
